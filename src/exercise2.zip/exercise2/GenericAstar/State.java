package exercise2.GenericAstar;


// Hvis man vil lage en egen state må denne arves.
public abstract class State {
	
	public abstract String toString ();

		
	
	
}
